from pathlib import Path
import subprocess
root=Path('/home/runner/workspace')
patch=Path(__file__).with_name('changes.patch')
subprocess.run(['git','apply','--check',str(patch)],cwd=root,check=True)
p=root/'artifacts/mobile/contexts/AppContext.tsx'
s=p.read_text()
assert 'drawFortune' not in s
s="import {prepareFortune,type FortuneInput,type FortuneState,type FortuneResult} from '@/utils/dailyFortune';\n"+s
s=s.replace('export interface FeedState {','export interface FeedState {\n  fortune?: FortuneState;')
s=s.replace('  runSmoking: (operation:', '  drawFortune: (input: FortuneInput) => Promise<FortuneResult>;\n  runSmoking: (operation:')
a=s.index('  const runSmoking =');b=s.index('\n\n',a)
block=s[a:b].replace('runSmoking','drawFortune').replace('operation: SmokingOperation','input: FortuneInput').replace('prepareSmoking(values, operation, getTodayDate(), Date.now(), defaultFeedState)','prepareFortune(values, input, getTodayDate(), defaultFeedState)').replace('saved.changed','saved.created').replace('return {state:saved.state,receipt:saved.receipt,changed:saved.created};','return {reading:saved.reading,created:saved.created};')
assert 'return {reading:saved.reading,created:saved.created}' in block
s=s[:a]+block+'\n\n'+s[a:];s=s.replace('        runSmoking,','        runSmoking,\n        drawFortune,')
subprocess.run(['git','apply',str(patch)],cwd=root,check=True)
p.write_text(s)
import shutil
payload=Path(__file__).with_name('new')
for src in payload.rglob('*'):
 if src.is_file():
  dest=root/src.relative_to(payload)
  assert not dest.exists(),str(dest)
  dest.parent.mkdir(parents=True,exist_ok=True)
  shutil.copy2(src,dest)
print('FORTUNE_AND_GIANT_PINS_APPLIED')
