export const EVOLVED_SHAPES = {
    odango: { radius: [43, 39, 36], floor: 36, eyeY: -3, mouthY: 10, sprout: false },
    stage3: { radius: [41, 35, 34], floor: 33, eyeY: 0, mouthY: 12, sprout: true },
    stage4: { radius: [41, 35, 34], floor: 33, eyeY: 0, mouthY: 12, sprout: true },
};
const norm = (a) => { const n = Math.hypot(...a) || 1; return a.map(v => v / n); };
const add = (a, b, s = 1) => a.map((v, i) => v + b[i] * s);
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const random = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453123; return x - Math.floor(x); };
export function evolvedRotation(rx, ry, rz) {
    const cx = Math.cos(rx), sx = Math.sin(rx), cy = Math.cos(ry), sy = Math.sin(ry), cz = Math.cos(rz), sz = Math.sin(rz);
    return [cy * cz, cy * sz, -sy, sx * sy * cz - cx * sz, sx * sy * sz + cx * cz, sx * cy, cx * sy * cz + sx * sz, cx * sy * sz - sx * cz, cx * cy];
}
export function evolvedGroundOffset(form, rotation) {
    const r = EVOLVED_SHAPES[form].radius;
    // Support point of the rotated ellipsoid, including the fur, stays grounded.
    return 91 - Math.sqrt((rotation[1] * r[0]) ** 2 + (rotation[4] * r[1]) ** 2 + (rotation[7] * r[2]) ** 2) - 2;
}
// Position, normal, hair tangent, ribbon side/width, material, variation.
const STRIDE = 14;
function vertex(out, p, n, t = [0, 1, 0], edge = 0, width = 0, material = 0, variation = 0) { out.push(...p, ...n, ...t, edge, width, material, variation, 0); }
function ellipsoid(out, center, r, material, rings = 20, slices = 32, floor = Infinity) {
    const at = (i, j) => { const a = i * Math.PI / rings, b = j * Math.PI * 2 / slices; const n = [Math.sin(a) * Math.cos(b), -Math.cos(a), Math.sin(a) * Math.sin(b)]; return { p: [center[0] + n[0] * r[0], center[1] + Math.min(floor, n[1] * r[1]), center[2] + n[2] * r[2]], n: norm([n[0] / r[0], n[1] / r[1], n[2] / r[2]]) }; };
    for (let i = 0; i < rings; i++)
        for (let j = 0; j < slices; j++)
            for (const [u, v] of [[i, j], [i + 1, j], [i, j + 1], [i, j + 1], [i + 1, j], [i + 1, j + 1]]) {
                const q = at(u, v);
                vertex(out, q.p, q.n, undefined, 0, 0, material);
            }
}
function tube(out, points, radius, material) {
    for (let i = 0; i < points.length - 1; i++) {
        const t = norm(add(points[i + 1], points[i], -1)), a = norm(cross(t, [0, 0, 1])), b = norm(cross(t, a));
        const at = (k, j) => { const angle = j * Math.PI / 4, n = add(a.map(v => v * Math.cos(angle)), b, Math.sin(angle)); return { p: add(points[k], n, radius), n }; };
        for (let j = 0; j < 8; j++)
            for (const [k, l] of [[i, j], [i + 1, j], [i, j + 1], [i, j + 1], [i + 1, j], [i + 1, j + 1]]) {
                const q = at(k, l);
                vertex(out, q.p, q.n, undefined, 0, 0, material);
            }
    }
}
export function createEvolvedMeshes(form, fibreCount = 10500) {
    const shape = EVOLVED_SHAPES[form], r = shape.radius;
    const surface = (x, y) => [x, y, r[2] * Math.sqrt(Math.max(0, 1 - (x / r[0]) ** 2 - (y / r[1]) ** 2))];
    const body = [], fur = [], leaves = [], eyes = [], mouth = [], openMouth = [], cigarette = [];
    ellipsoid(body, [0, 0, 0], r, 0, 26, 48, shape.floor);
    for (let i = 0; i < fibreCount; i++) {
        const y = 1 - 2 * (i + .5) / fibreCount, a = i * 2.399963229728653, s = Math.sqrt(1 - y * y);
        const p = [r[0] * s * Math.cos(a), Math.min(shape.floor, r[1] * y), r[2] * s * Math.sin(a)];
        const n = norm([p[0] / r[0] ** 2, p[1] / r[1] ** 2, p[2] / r[2] ** 2]);
        // Comb gently away from the forehead. The same continuous coat covers the rear.
        const down = [p[0] * .018, .5 + p[1] * .013, p[2] * .009];
        const tangent = norm(add(down, n, -dot(down, n)));
        const length = 1.2 + random(i) * 2.3, bend = 1.1 + random(i + 8) * 2.4, variation = random(i + 49);
        const at = (t) => { let q = add(add(p, n, length * t), tangent, bend * t * t); q[1] = Math.min(shape.floor + 1.3, q[1]); return q; };
        for (let k = 0; k < 2; k++) {
            const a = k / 2, b = (k + 1) / 2, pa = at(a), pb = at(b), t = norm(add(pb, pa, -1));
            for (const [u, side] of [[a, -1], [b, -1], [a, 1], [a, 1], [b, -1], [b, 1]]) {
                const q = u === a ? pa : pb;
                vertex(fur, q, n, t, side, (.09 + variation * .075) * (1 - u * .92), 1, variation);
            }
        }
    }
    // Eyes keep the original spacing, round black shape and small white glints.
    for (const x of [-10.1, 10.1]) {
        const p = surface(x, shape.eyeY);
        p[2] += .5;
        ellipsoid(eyes, p, [4.7, 5.0, 2.5], 2, 12, 20);
        p[2] += 1.3;
        ellipsoid(eyes, p, [3.9, 4.25, 2.5], 3, 16, 24);
    }
    const path = [];
    for (let i = 0; i <= 24; i++) {
        const x = -7.5 + i * 15 / 24, p = surface(x, shape.mouthY);
        p[2] += 2.1;
        path.push(p);
    }
    tube(mouth, path, .9, 4);
    const op = surface(0, shape.mouthY);
    op[2] += 2.1;
    ellipsoid(openMouth, op, [4.1, 4.7, 1.1], 5, 12, 20);
    if (shape.sprout) {
        tube(leaves, [[0, -r[1] + 1, 0], [.2, -r[1] - 4, .4], [1, -r[1] - 9, 0]], .8, 6);
        for (const side of [-1, 1]) {
            const base = [.6, -r[1] - 5, 0], tip = [side * 15, -r[1] - 17, side * 1.8];
            const point = (t, w) => { const width = Math.sin(Math.PI * t) * 5.3; return [base[0] + (tip[0] - base[0]) * t + side * width * w * .45, base[1] + (tip[1] - base[1]) * t + width * w * .5, base[2] + (tip[2] - base[2]) * t + width * (1 - w * w) * .48 + width * w * .75]; };
            for (let i = 0; i < 12; i++)
                for (let j = 0; j < 6; j++) {
                    const a = i / 12, b = (i + 1) / 12, c = j / 3 - 1, d = (j + 1) / 3 - 1;
                    for (const tri of [[[a, c], [b, c], [a, d]], [[a, d], [b, c], [b, d]]]) {
                        const points = tri.map(([t, w]) => point(t, w));
                        const n = norm(cross(add(points[1], points[0], -1), add(points[2], points[0], -1)));
                        for (const p of points)
                            vertex(leaves, p, n, undefined, 0, 0, 7);
                    }
                }
            tube(leaves, Array.from({ length: 13 }, (_, i) => add(point(i / 12, 0), [0, 0, .12])), .17, 8);
            for (const t of [.3, .48, .66])
                for (const w of [-1, 1])
                    tube(leaves, [add(point(t, 0), [0, 0, .13]), add(point(t + .16, w * .82), [0, 0, .13])], .07, 8);
        }
    }
    const c = surface(7.5, shape.mouthY);
    c[2] += 3;
    const cp = (x) => [c[0] + x, c[1] - .04 * x, c[2] + x * .22];
    tube(cigarette, [cp(0), cp(5)], 1, 9);
    tube(cigarette, [cp(5), cp(18)], 1, 10);
    tube(cigarette, [cp(18), cp(19)], 1, 11);
    const mesh = (data) => ({ data: new Float32Array(data), count: data.length / STRIDE });
    return { body: mesh(body), fur: mesh(fur), eyes: mesh(eyes), mouth: mesh(mouth), openMouth: mesh(openMouth), leaves: mesh(leaves), cigarette: mesh(cigarette) };
}
const VERTEX = `
attribute vec3 aPosition,aNormal,aTangent;
attribute vec2 aRibbon;
attribute float aMaterial,aVariation;
uniform mat3 uRotation;
uniform float uOrigin,uBlink,uHappy,uEyeY,uMouthY,uOpen;
varying vec3 vNormal,vPosition;
varying float vEdge,vMaterial,vVariation;
void main(){
 vec3 p=aPosition;
 if(aMaterial>1.5&&aMaterial<3.5) p.y=uEyeY+(p.y-uEyeY)*max(.10,1.-uBlink);
 if(aMaterial>3.5&&aMaterial<4.5) p.y+=(uHappy>0.5?1.:-1.)*2.2*(1.-pow(p.x/8.5,2.));
 if(aMaterial>4.5&&aMaterial<5.5) p.y=uMouthY+(p.y-uMouthY)*uOpen;
 vec3 q=uRotation*p;
 vec3 tangent=uRotation*aTangent;
 vec2 side=normalize(vec2(-tangent.y,tangent.x)+vec2(.00001));
 q.xy+=side*aRibbon.x*aRibbon.y;
 gl_Position=vec4(q.x/50.,-(q.y+uOrigin-50.)/50.,-q.z/100.,1.);
 vNormal=normalize(uRotation*aNormal);vPosition=p;
 vEdge=aRibbon.x;vMaterial=aMaterial;vVariation=aVariation;
}`;
const FRAGMENT = `
precision mediump float;
uniform float uRainbow,uNight,uEyeY;
varying vec3 vNormal,vPosition;
varying float vEdge,vMaterial,vVariation;
vec3 coat(vec3 p){
 vec3 c=vec3(.98,.968,.935);
 if(uRainbow>.5){
  float a=atan(p.x,p.y+7.)+p.z*.01;
  c=.79+.17*cos(a+vec3(0.,2.094,4.188));
  c=mix(c,vec3(1.,.9,.58),exp(-dot((p.xy-vec2(-2.,-25.))/22.,(p.xy-vec2(-2.,-25.))/22.))*.75);
 }
 float cheek=(exp(-dot((p.xy-vec2(-18.,uEyeY+8.))/vec2(6.2,3.9),(p.xy-vec2(-18.,uEyeY+8.))/vec2(6.2,3.9)))+exp(-dot((p.xy-vec2(18.,uEyeY+8.))/vec2(6.2,3.9),(p.xy-vec2(18.,uEyeY+8.))/vec2(6.2,3.9))))*smoothstep(20.,29.,p.z);
 return mix(c,vec3(.95,.63,.65),cheek*.6);
}
void main(){
 vec3 n=normalize(vNormal),light=normalize(vec3(-.45,-.68,.8));
 float diffuse=max(0.,dot(n,light)),rim=pow(1.-abs(n.z),2.);
 float illumination=.70+.28*diffuse-.10*smoothstep(15.,40.,vPosition.y);
 vec3 color=coat(vPosition);float alpha=1.;
 if(vMaterial<1.5){
  if(vMaterial>.5){alpha=(1.-smoothstep(.15,1.,abs(vEdge)))*.92;color*=.85+.19*vVariation;}
  color*=illumination;color+=vec3(.035)*rim;
 }else if(vMaterial<2.5){color=vec3(.54,.55,.50)*illumination;}
 else if(vMaterial<3.5){
  color=vec3(.022,.028,.021)+vec3(.035)*diffuse;
  float shine=pow(max(0.,dot(reflect(-light,n),vec3(0.,0.,1.))),55.);
  color+=vec3(.95)*shine;
 }else if(vMaterial<4.5){color=vec3(.08,.095,.064)*illumination;}
 else if(vMaterial<5.5){color=vec3(.28,.16,.16)*illumination;}
 else if(vMaterial<6.5){color=vec3(.37,.61,.14)*illumination;}
 else if(vMaterial<7.5){color=vec3(.38,.68,.12)*(.74+.26*abs(dot(n,light)));color+=vec3(.10,.12,.015)*pow(max(0.,dot(n,light)),12.);}
 else if(vMaterial<8.5){color=vec3(.65,.79,.27)*illumination;}
 else if(vMaterial<9.5){color=vec3(.80,.61,.36)*illumination;}
 else if(vMaterial<10.5){color=vec3(.96,.94,.88)*illumination;}
 else{color=vec3(.97,.38,.17);}
 color*=mix(vec3(1.),vec3(.85,.89,1.),uNight*.6);
 gl_FragColor=vec4(color,alpha);
}`;
export function createEvolvedRenderer(canvas, form) {
    const gl = canvas.getContext('webgl', { alpha: true, antialias: true, premultipliedAlpha: false, powerPreference: 'low-power', preserveDrawingBuffer: false });
    if (!gl)
        throw new Error('WebGL unavailable');
    const shaders = [];
    const compile = (source, type) => { const shader = gl.createShader(type); shaders.push(shader); gl.shaderSource(shader, source); gl.compileShader(shader); if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS))
        throw new Error(gl.getShaderInfoLog(shader) || 'shader'); return shader; };
    const program = gl.createProgram();
    gl.attachShader(program, compile(VERTEX, gl.VERTEX_SHADER));
    gl.attachShader(program, compile(FRAGMENT, gl.FRAGMENT_SHADER));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS))
        throw new Error(gl.getProgramInfoLog(program) || 'link');
    const source = createEvolvedMeshes(form), buffers = Object.fromEntries(Object.entries(source).map(([key, mesh]) => { const buffer = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buffer); gl.bufferData(gl.ARRAY_BUFFER, mesh.data, gl.STATIC_DRAW); return [key, { buffer, count: mesh.count }]; }));
    const attributes = [['aPosition', 3, 0], ['aNormal', 3, 3], ['aTangent', 3, 6], ['aRibbon', 2, 9], ['aMaterial', 1, 11], ['aVariation', 1, 12]];
    const locations = attributes.map(([name, size, offset]) => ({ location: gl.getAttribLocation(program, name), size, offset }));
    const uniforms = Object.fromEntries(['uRotation', 'uOrigin', 'uBlink', 'uHappy', 'uEyeY', 'uMouthY', 'uOpen', 'uRainbow', 'uNight'].map(name => [name, gl.getUniformLocation(program, name)]));
    const shape = EVOLVED_SHAPES[form];
    let disposed = false;
    const draw = (key) => { const mesh = buffers[key]; gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buffer); for (const a of locations) {
        if (a.location < 0)
            continue;
        gl.enableVertexAttribArray(a.location);
        gl.vertexAttribPointer(a.location, a.size, gl.FLOAT, false, STRIDE * 4, a.offset * 4);
    } gl.drawArrays(gl.TRIANGLES, 0, mesh.count); };
    return {
        render(pose) {
            if (disposed || gl.isContextLost())
                return;
            gl.viewport(0, 0, canvas.width, canvas.height);
            gl.clearColor(0, 0, 0, 0);
            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            gl.useProgram(program);
            const rotation = evolvedRotation(pose.rx, pose.ry, pose.rz);
            gl.uniformMatrix3fv(uniforms.uRotation, false, rotation);
            gl.uniform1f(uniforms.uOrigin, evolvedGroundOffset(form, rotation));
            gl.uniform1f(uniforms.uBlink, pose.sleepy ? 1 : pose.blink);
            gl.uniform1f(uniforms.uHappy, pose.happy ? 1 : 0);
            gl.uniform1f(uniforms.uEyeY, shape.eyeY);
            gl.uniform1f(uniforms.uMouthY, shape.mouthY);
            gl.uniform1f(uniforms.uOpen, pose.mouthOpen);
            gl.uniform1f(uniforms.uRainbow, form === 'stage4' ? 1 : 0);
            gl.uniform1f(uniforms.uNight, pose.night ? 1 : 0);
            gl.enable(gl.DEPTH_TEST);
            gl.depthMask(true);
            gl.disable(gl.BLEND);
            draw('body');
            draw('leaves');
            draw('eyes');
            if (pose.mouthOpen > .08)
                draw('openMouth');
            else
                draw('mouth');
            if (pose.smoking)
                draw('cigarette');
            gl.enable(gl.BLEND);
            gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
            gl.depthMask(false);
            draw('fur');
            gl.depthMask(true);
        },
        dispose() { if (disposed)
            return; disposed = true; Object.values(buffers).forEach(({ buffer }) => gl.deleteBuffer(buffer)); shaders.forEach(shader => gl.deleteShader(shader)); gl.deleteProgram(program); gl.getExtension('WEBGL_lose_context')?.loseContext(); },
    };
}
